package com.example.myapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.File;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "diet.db";
    private static final int DATABASE_VERSION = 1;

    // 摘要表
    public static final String SUMMARY_TABLE = "summary";
    public static final String SUMMARY_COLUMN_DATE = "date";
    public static final String SUMMARY_COLUMN_PROTEIN = "protein";
    public static final String SUMMARY_COLUMN_CARB = "carb";
    public static final String SUMMARY_COLUMN_OTHER = "other";

    // 详细表
    public static final String DETAILS_TABLE = "details";
    public static final String DETAILS_COLUMN_DATE = "date";
    public static final String DETAILS_COLUMN_CATEGORY = "category";
    public static final String DETAILS_COLUMN_NAME = "name";
    public static final String DETAILS_COLUMN_AMOUNT = "amount";
    public static final String DETAILS_COLUMN_UNIT = "unit";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // 创建摘要表
        db.execSQL("CREATE TABLE " + SUMMARY_TABLE + " (" +
                SUMMARY_COLUMN_DATE + " TEXT PRIMARY KEY, " +
                SUMMARY_COLUMN_PROTEIN + " TEXT, " +
                SUMMARY_COLUMN_CARB + " TEXT, " +
                SUMMARY_COLUMN_OTHER + " TEXT)");

        // 创建详细表
        db.execSQL("CREATE TABLE " + DETAILS_TABLE + " (" +
                DETAILS_COLUMN_DATE + " TEXT, " +
                DETAILS_COLUMN_CATEGORY + " TEXT, " +
                DETAILS_COLUMN_NAME + " TEXT, " +
                DETAILS_COLUMN_AMOUNT + " TEXT, " +
                DETAILS_COLUMN_UNIT + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + SUMMARY_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + DETAILS_TABLE);
        onCreate(db);
    }

    // 插入摘要记录
    public void insertSummaryRecord(String date, String protein, String carb, String other) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(SUMMARY_COLUMN_DATE, date);
        values.put(SUMMARY_COLUMN_PROTEIN, protein);
        values.put(SUMMARY_COLUMN_CARB, carb);
        values.put(SUMMARY_COLUMN_OTHER, other);
        db.insert(SUMMARY_TABLE, null, values);
        db.close();
    }

    // 插入详细记录
    public void insertDetailedRecord(String date, String category, String name, String amount, String unit) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DETAILS_COLUMN_DATE, date);
        values.put(DETAILS_COLUMN_CATEGORY, category);
        values.put(DETAILS_COLUMN_NAME, name);
        values.put(DETAILS_COLUMN_AMOUNT, amount);
        values.put(DETAILS_COLUMN_UNIT, unit);
        db.insert(DETAILS_TABLE, null, values);
        db.close();
    }

    // 查询所有摘要记录
    public Cursor getAllSummaryRecords() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + SUMMARY_TABLE, null);
    }

    // 查询某次提交的详细记录
    public Cursor getDetailedRecords(String date) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + DETAILS_TABLE +
                " WHERE " + DETAILS_COLUMN_DATE + " = ?", new String[]{date});
    }
}
