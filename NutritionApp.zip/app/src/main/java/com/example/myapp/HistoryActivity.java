package com.example.myapp;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private DatabaseHelper dbHelper;
    private HistoryAdapter adapter;
    private List<History> historyList;
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        btnBack = findViewById(R.id.btn_back);
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new DatabaseHelper(this);
        historyList = new ArrayList<>();

        loadSummaryRecords();

        adapter = new HistoryAdapter(historyList);
        recyclerView.setAdapter(adapter);

        btnBack.setOnClickListener(v -> finish());
    }

    private void loadSummaryRecords() {
        Cursor cursor = dbHelper.getAllSummaryRecords();
        historyList.clear();

        while (cursor.moveToNext()) {
            String date = cursor.getString(cursor.getColumnIndex(DatabaseHelper.SUMMARY_COLUMN_DATE));
            String protein = cursor.getString(cursor.getColumnIndex(DatabaseHelper.SUMMARY_COLUMN_PROTEIN));
            String carb = cursor.getString(cursor.getColumnIndex(DatabaseHelper.SUMMARY_COLUMN_CARB));
            String other = cursor.getString(cursor.getColumnIndex(DatabaseHelper.SUMMARY_COLUMN_OTHER));

            List<String> summaryDetails = new ArrayList<>();
            summaryDetails.add("Protein: " + protein);
            summaryDetails.add("Carbs: " + carb);
            summaryDetails.add("Others: " + other);

            historyList.add(new History(date, summaryDetails, false));
        }
        cursor.close();
    }
}
