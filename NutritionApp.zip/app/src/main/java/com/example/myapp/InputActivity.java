package com.example.myapp;

import android.os.Bundle;
import java.text.SimpleDateFormat;
import java.util.*;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomsheet.BottomSheetDialog;

public class InputActivity extends AppCompatActivity {
    private LinearLayout PContainer, CContainer, OContainer;
    private Button btnAddProtein, btnAddCarb, btnAddOther, btnSubmit, btnBack;
    private ArrayList<ProteinInput> proteinRows = new ArrayList<>();
    private ArrayList<ProteinInput> carbRows = new ArrayList<>();
    private ArrayList<ProteinInput> otherRows = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);


        PContainer = findViewById(R.id.Pcontainer);
        CContainer = findViewById(R.id.Ccontainer);
        OContainer = findViewById(R.id.Ocontainer);
        btnAddProtein = findViewById(R.id.btn_add_protein);
        btnAddCarb = findViewById(R.id.btn_add_carb);
        btnAddOther = findViewById(R.id.btn_add_other);
        btnSubmit = findViewById(R.id.btn_submit);
        btnBack = findViewById(R.id.btn_back);


        initializeStaticInputs();


        btnAddProtein.setOnClickListener(v -> addNewProteinRow(PContainer));
        btnAddCarb.setOnClickListener(v -> addNewCarbRow(CContainer));
        btnAddOther.setOnClickListener(v -> addNewOtherRow(OContainer));


        btnSubmit.setOnClickListener(v -> collectAndDisplayData());

        btnBack.setOnClickListener(v -> finish());
    }

    private void initializeStaticInputs() {

        EditText proteinName = findViewById(R.id.editTextP);
        EditText proteinAmount = findViewById(R.id.editTextPP);
        Spinner proteinUnit = findViewById(R.id.spinner_P);
        proteinRows.add(new ProteinInput(proteinName, proteinAmount, proteinUnit));


        EditText carbName = findViewById(R.id.editTextC);
        EditText carbAmount = findViewById(R.id.editTextCP);
        Spinner carbUnit = findViewById(R.id.spinner_C);
        carbRows.add(new ProteinInput(carbName, carbAmount, carbUnit));


        EditText otherName = findViewById(R.id.editTextO);
        EditText otherAmount = findViewById(R.id.editTextOP);
        Spinner otherUnit = findViewById(R.id.spinner_O);
        otherRows.add(new ProteinInput(otherName, otherAmount, otherUnit));
    }

    private void addNewProteinRow(LinearLayout container) {
        View proteinRow = LayoutInflater.from(this).inflate(R.layout.protein_input, container, false);
        EditText nameInput = proteinRow.findViewById(R.id.editTextP);
        EditText amountInput = proteinRow.findViewById(R.id.editTextPP);
        Spinner unitSpinner = proteinRow.findViewById(R.id.spinner_P);
        proteinRows.add(new ProteinInput(nameInput, amountInput, unitSpinner));
        container.addView(proteinRow);
    }

    private void addNewCarbRow(LinearLayout container) {
        View carbRow = LayoutInflater.from(this).inflate(R.layout.carb_input, container, false);
        EditText nameInput = carbRow.findViewById(R.id.editTextC);
        EditText amountInput = carbRow.findViewById(R.id.editTextCP);
        Spinner unitSpinner = carbRow.findViewById(R.id.spinner_C);
        carbRows.add(new ProteinInput(nameInput, amountInput, unitSpinner));
        container.addView(carbRow);
    }

    private void addNewOtherRow(LinearLayout container) {
        View otherRow = LayoutInflater.from(this).inflate(R.layout.other_input, container, false);
        EditText nameInput = otherRow.findViewById(R.id.editTextO);
        EditText amountInput = otherRow.findViewById(R.id.editTextOP);
        Spinner unitSpinner = otherRow.findViewById(R.id.spinner_O);
        otherRows.add(new ProteinInput(nameInput, amountInput, unitSpinner));
        container.addView(otherRow);
    }

    private void collectAndDisplayData() {
        StringBuilder data = new StringBuilder();


        data.append("Protein:\n");
        for (ProteinInput input : proteinRows) {
            data.append("- Name: ").append(input.getName())
                    .append(", Amount: ").append(input.getAmount())
                    .append(", Unit: ").append(input.getUnit()).append("\n");
        }

        data.append("Carbs:\n");
        for (ProteinInput input : carbRows) {
            data.append("- Name: ").append(input.getName())
                    .append(", Amount: ").append(input.getAmount())
                    .append(", Unit: ").append(input.getUnit()).append("\n");
        }

        data.append("Others:\n");
        for (ProteinInput input : otherRows) {
            data.append("- Name: ").append(input.getName())
                    .append(", Amount: ").append(input.getAmount())
                    .append(", Unit: ").append(input.getUnit()).append("\n");
        }

        showBottomSheetDialog(data.toString());
    }

    public void showBottomSheetDialog(String userInputContent) {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        View bottomSheetView = LayoutInflater.from(this).inflate(R.layout.bottom_sheet_layout, null);

        TextView tvUserInput = bottomSheetView.findViewById(R.id.tv_user_input);
        Button btnModify = bottomSheetView.findViewById(R.id.btn_modify);
        Button btnConfirm = bottomSheetView.findViewById(R.id.btn_confirm);

        tvUserInput.setText(userInputContent);

        bottomSheetDialog.setContentView(bottomSheetView);
        bottomSheetDialog.show();


        btnModify.setOnClickListener(v -> bottomSheetDialog.dismiss());

        btnConfirm.setOnClickListener(v -> {
            saveDataToDatabase();
            Toast.makeText(this, "Data saved successfully!", Toast.LENGTH_SHORT).show();
            bottomSheetDialog.dismiss();
            finish();
        });
    }


    private void saveDataToDatabase() {
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        StringBuilder proteinSummary = new StringBuilder();
        StringBuilder carbSummary = new StringBuilder();
        StringBuilder otherSummary = new StringBuilder();


        for (ProteinInput input : proteinRows) {
            if (!input.getName().isEmpty() && !input.getAmount().isEmpty()) {
                dbHelper.insertDetailedRecord(date, "Protein", input.getName(), input.getAmount(), input.getUnit());
                proteinSummary.append(input.getName()).append(" ").append(input.getAmount()).append(input.getUnit()).append(", ");
            }
        }


        for (ProteinInput input : carbRows) {
            if (!input.getName().isEmpty() && !input.getAmount().isEmpty()) {
                dbHelper.insertDetailedRecord(date, "Carbs", input.getName(), input.getAmount(), input.getUnit());
                carbSummary.append(input.getName()).append(" ").append(input.getAmount()).append(input.getUnit()).append(", ");
            }
        }


        for (ProteinInput input : otherRows) {
            if (!input.getName().isEmpty() && !input.getAmount().isEmpty()) {
                dbHelper.insertDetailedRecord(date, "Others", input.getName(), input.getAmount(), input.getUnit());
                otherSummary.append(input.getName()).append(" ").append(input.getAmount()).append(input.getUnit()).append(", ");
            }
        }


        if (proteinSummary.length() > 0) proteinSummary.setLength(proteinSummary.length() - 2);
        if (carbSummary.length() > 0) carbSummary.setLength(carbSummary.length() - 2);
        if (otherSummary.length() > 0) otherSummary.setLength(otherSummary.length() - 2);

        dbHelper.insertSummaryRecord(date, proteinSummary.toString(), carbSummary.toString(), otherSummary.toString());
        Toast.makeText(this, "Data saved successfully!", Toast.LENGTH_SHORT).show();
    }

    class ProteinInput {
        EditText nameInput;
        EditText amountInput;
        Spinner unitSpinner;

        ProteinInput(EditText nameInput, EditText amountInput, Spinner unitSpinner) {
            this.nameInput = nameInput;
            this.amountInput = amountInput;
            this.unitSpinner = unitSpinner;
        }

        String getName() {
            return nameInput.getText().toString().trim();
        }

        String getAmount() {
            return amountInput.getText().toString().trim();
        }

        String getUnit() {
            return unitSpinner.getSelectedItem().toString();
        }
    }
}
